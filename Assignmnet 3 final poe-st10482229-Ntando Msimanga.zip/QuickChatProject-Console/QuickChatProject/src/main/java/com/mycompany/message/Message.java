package com.mycompany.message;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Message {
    private static int nextNumber = 0;
    private static final ArrayList<Message> sentMessages = new ArrayList<>();
    private static final ArrayList<Message> disregardedMessages = new ArrayList<>();
    private static final ArrayList<Message> storedMessages = new ArrayList<>();
    private final String messageID;
    private final int messageNumber;
    private final String recipientCell;
    private final String message;

    public Message(String recipientCell, String message) {
        this(String.format("%02d%08d", nextNumber % 100,
                ThreadLocalRandom.current().nextInt(100_000_000)),
                nextNumber++, recipientCell, message);
    }

    public Message(String messageID, int messageNumber, String recipientCell, String message) {
        this.messageID = messageID;
        this.messageNumber = messageNumber;
        this.recipientCell = recipientCell;
        this.message = message;
    }

    public String getMessageID() { return messageID; }
    public String getRecipientCell() { return recipientCell; }
    public String getMessage() { return message; }
    public String getMessageHash() { return createMessageHash(); }

    public boolean checkMessageID() {
        return messageID != null && !messageID.isEmpty() && messageID.length() <= 10;
    }

    public String checkMessageLength() {
        if (message != null && message.length() <= 250) return "Message ready to send.";
        int size = message == null ? 0 : message.length();
        return "Message exceeds 250 characters by " + (size - 250) + "; please reduce the size.";
    }

    public String checkRecipientCell() {
        return Login.isValidCellPhoneNumber(recipientCell)
                ? "Cell phone number successfully captured."
                : "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
    }

    public String createMessageHash() {
        String[] words = (message == null || message.trim().isEmpty())
                ? new String[]{"", ""} : message.trim().split("\\s+");
        String first = words[0].replaceAll("[^\\p{L}\\p{N}]", "");
        String last = words[words.length - 1].replaceAll("[^\\p{L}\\p{N}]", "");
        return (messageID.substring(0, Math.min(2, messageID.length())) + ":" + messageNumber + ":" + first + last)
                .toUpperCase(Locale.ROOT);
    }

    // 1 = send, 2 = disregard, 3 = store.
    public String SentMessage(int choice) {
        if (!checkMessageID()) return "Message ID must be no more than 10 characters.";
        if (!"Message ready to send.".equals(checkMessageLength())) return checkMessageLength();
        if (!"Cell phone number successfully captured.".equals(checkRecipientCell())) return checkRecipientCell();
        if (choice == 1) {
            if (!sentMessages.contains(this)) sentMessages.add(this);
            return "Message successfully sent.";
        }
        if (choice == 2) {
            if (!disregardedMessages.contains(this)) disregardedMessages.add(this);
            return "Press 0 to delete the message.";
        }
        if (choice == 0) {
            disregardedMessages.remove(this);
            return "Message deleted.";
        }
        if (choice == 3) {
            try { storeMessage(); return "Message successfully stored."; }
            catch (IOException ex) { return "Could not store the message: " + ex.getMessage(); }
        }
        return "Please choose 1, 2, or 3.";
    }

    public String SentMessage(Scanner input) {
        String choice = input.nextLine().trim();
        try {
            return SentMessage(Integer.parseInt(choice));
        } catch (NumberFormatException ex) {
            return "Please choose Send Message, Disregard Message, or Store Message.";
        }
    }

    public static ArrayList<Message> getSentMessages() { return new ArrayList<>(sentMessages); }
    public static ArrayList<Message> getDisregardedMessages() { return new ArrayList<>(disregardedMessages); }
    public static ArrayList<Message> getStoredMessages() { loadStoredMessages(); return new ArrayList<>(storedMessages); }
    public static int returnTotalMessagess() { return sentMessages.size(); }
    public static String printMessages() { return formatMessages(sentMessages); }

    public static String formatMessages(ArrayList<Message> list) {
        if (list.isEmpty()) return "No messages found.";
        StringBuilder out = new StringBuilder();
        for (Message item : list) {
            if (out.length() > 0) out.append("\n\n");
            out.append("Message ID: ").append(item.messageID)
               .append("\nMessage Hash: ").append(item.createMessageHash())
               .append("\nRecipient: ").append(item.recipientCell)
               .append("\nMessage: ").append(item.message);
        }
        return out.toString();
    }

    private static ArrayList<Message> allMessages() {
        loadStoredMessages();
        ArrayList<Message> all = new ArrayList<>();
        all.addAll(sentMessages); all.addAll(disregardedMessages); all.addAll(storedMessages);
        return all;
    }

    public static Message getLongestMessage() {
        Message longest = null;
        for (Message item : allMessages())
            if (longest == null || item.message.length() > longest.message.length()) longest = item;
        return longest;
    }

    public static Message findByID(String id) {
        for (Message item : allMessages()) if (item.messageID.equals(id)) return item;
        return null;
    }

    public static ArrayList<Message> findByRecipient(String recipient) {
        ArrayList<Message> result = new ArrayList<>();
        for (Message item : allMessages()) if (item.recipientCell.equals(recipient)) result.add(item);
        return result;
    }

    public static String displayReport() { return formatMessages(allMessages()); }

    public static boolean deleteByHash(String hash) throws IOException {
        loadStoredMessages();
        for (int i = 0; i < storedMessages.size(); i++) {
            if (storedMessages.get(i).createMessageHash().equalsIgnoreCase(hash)) {
                storedMessages.remove(i); saveStoredMessages(storeFile()); return true;
            }
        }
        return false;
    }

    public void storeMessage() throws IOException {
        storeMessage(storeFile().toString());
    }

    public void storeMessage(String fileName) throws IOException {
        loadStoredMessages();
        boolean alreadyStored = false;
        for (Message item : storedMessages) {
            if (item.messageID.equals(messageID)) {
                alreadyStored = true;
                break;
            }
        }
        if (!alreadyStored) storedMessages.add(this);
        saveStoredMessages(Paths.get(fileName));
    }

    private static Path storeFile() { return Paths.get("stored_messages.json"); }

    private static void loadStoredMessages() {
        Path file = storeFile();
        if (!storedMessages.isEmpty() || !Files.exists(file)) return;
        try {
            String json = new String(Files.readAllBytes(file), StandardCharsets.UTF_8);
            Matcher objects = Pattern.compile("\\{([^}]*)\\}").matcher(json);
            while (objects.find()) {
                String obj = objects.group(1);
                String id = field(obj, "messageID");
                String recipient = field(obj, "recipientCell");
                String text = field(obj, "message");
                if (id != null && recipient != null && text != null)
                    storedMessages.add(new Message(id, nextNumber++, recipient, text));
            }
        } catch (IOException ex) {
            System.out.println("Could not read stored messages: " + ex.getMessage());
        }
    }

    private static String field(String object, String key) {
        Matcher m = Pattern.compile("\"" + Pattern.quote(key) + "\"\\s*:\\s*\"((?:\\\\.|[^\"\\\\])*)\"").matcher(object);
        return m.find() ? unescape(m.group(1)) : null;
    }

    private static String unescape(String value) {
        return value.replace("\\n", "\n").replace("\\r", "\r").replace("\\t", "\t")
                    .replace("\\\"", "\"").replace("\\\\", "\\");
    }

    private static String quote(String value) {
        StringBuilder out = new StringBuilder("\"");
        for (char c : value.toCharArray()) {
            if (c == '"' || c == '\\') out.append('\\').append(c);
            else if (c == '\n') out.append("\\n");
            else if (c == '\r') out.append("\\r");
            else if (c == '\t') out.append("\\t");
            else if (c < 32) out.append(String.format("\\u%04x", (int)c));
            else out.append(c);
        }
        return out.append('"').toString();
    }

    private static void saveStoredMessages(Path file) throws IOException {
        StringBuilder json = new StringBuilder("[\n");
        for (int i = 0; i < storedMessages.size(); i++) {
            Message item = storedMessages.get(i);
            if (i > 0) json.append(",\n");
            json.append("  {\"messageID\": ").append(quote(item.messageID))
                .append(", \"messageHash\": ").append(quote(item.createMessageHash()))
                .append(", \"recipientCell\": ").append(quote(item.recipientCell))
                .append(", \"message\": ").append(quote(item.message)).append("}");
        }
        json.append("\n]\n");
        Files.write(file, json.toString().getBytes(StandardCharsets.UTF_8));
    }
}
