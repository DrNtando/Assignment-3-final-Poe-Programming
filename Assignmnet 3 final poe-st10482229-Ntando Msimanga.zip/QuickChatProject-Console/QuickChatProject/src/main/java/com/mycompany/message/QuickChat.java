package com.mycompany.message;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class QuickChat {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Create a username: "); String username = input.nextLine();
        System.out.print("Create a password: "); String password = input.nextLine();
        System.out.print("Enter your first name: "); String first = input.nextLine();
        System.out.print("Enter your last name: "); String last = input.nextLine();
        System.out.print("Enter your cell phone number with international code: ");
        String phone = input.nextLine();

        Login login = new Login(username, password, first, last, phone);
        System.out.println(login.registerUser());
        if (!login.checkUserName() || !login.checkPasswordComplexity() || !login.checkCellPhoneNumber()) return;

        System.out.print("\nEnter your username to log in: ");
        String user = input.nextLine();
        System.out.print("Enter your password to log in: ");
        boolean success = login.loginUser(user, input.nextLine());
        System.out.println(login.returnLoginStatus(success));
        if (!success) return;

        boolean running = true;
        while (running) {
            System.out.println("\n--- QuickChat ---\n1) Create message\n2) Display sent messages\n3) Total sent messages\n4) Stored Messages\n0) Quit");
            System.out.print("Choose: ");
            switch (input.nextLine().trim()) {
                case "1": createMessage(input); break;
                case "2": System.out.println(Message.printMessages()); break;
                case "3": System.out.println("Total sent: " + Message.returnTotalMessagess()); break;
                case "4": storedMenu(input); break;
                case "0": running = false; break;
                default: System.out.println("Choose 0, 1, 2, 3, or 4.");
            }
        }
        input.close();
    }

    private static void createMessage(Scanner input) {
        System.out.print("Recipient number with international code: ");
        String recipient = input.nextLine();
        System.out.print("Message (maximum 250 characters): ");
        Message message = new Message(recipient, input.nextLine());
        System.out.println("Message ID: " + message.getMessageID());
        if (!"Message ready to send.".equals(message.checkMessageLength())) {
            System.out.println(message.checkMessageLength()); return;
        }
        if (!"Cell phone number successfully captured.".equals(message.checkRecipientCell())) {
            System.out.println(message.checkRecipientCell()); return;
        }
        System.out.print("1 Send, 2 Disregard, 3 Store: ");
        try { System.out.println(message.SentMessage(Integer.parseInt(input.nextLine().trim()))); }
        catch (NumberFormatException ex) { System.out.println("Enter 1, 2, or 3."); }
    }

    private static void storedMenu(Scanner input) {
        boolean open = true;
        while (open) {
            System.out.println("\n--- Stored Messages ---\na) Sender and recipient\nb) Longest message\nc) Search by ID\nd) Search by recipient\ne) Delete by hash\nf) Full report\nx) Main menu");
            System.out.print("Choose: ");
            switch (input.nextLine().trim().toLowerCase()) {
                case "a":
                    ArrayList<Message> stored = Message.getStoredMessages();
                    if (stored.isEmpty()) System.out.println("No stored messages.");
                    for (Message m : stored) System.out.println("Sender: " + loginName + " | Recipient: " + m.getRecipientCell());
                    break;
                case "b":
                    Message longest = Message.getLongestMessage();
                    System.out.println(longest == null ? "No messages available." : longest.getMessage());
                    break;
                case "c":
                    System.out.print("Message ID: ");
                    Message found = Message.findByID(input.nextLine().trim());
                    if (found == null) System.out.println("Message not found.");
                    else System.out.println("Recipient: " + found.getRecipientCell() + "\nMessage: " + found.getMessage());
                    break;
                case "d":
                    System.out.print("Recipient number: ");
                    System.out.println(Message.formatMessages(Message.findByRecipient(input.nextLine().trim())));
                    break;
                case "e":
                    System.out.print("Message hash: ");
                    try { System.out.println(Message.deleteByHash(input.nextLine().trim()) ? "Message successfully deleted." : "Message hash not found."); }
                    catch (IOException ex) { System.out.println("Could not delete message: " + ex.getMessage()); }
                    break;
                case "f": System.out.println(Message.displayReport()); break;
                case "x": open = false; break;
                default: System.out.println("Choose a, b, c, d, e, f, or x.");
            }
        }
    }

    private static String loginName = "Logged-in user";
}
